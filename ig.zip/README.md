git clone https://github.com/anadhelf/ig/
cd ig
node flmauto.js
